package org.junit.tests.experimental.theories.extendingwithstubs;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Stub {
}
